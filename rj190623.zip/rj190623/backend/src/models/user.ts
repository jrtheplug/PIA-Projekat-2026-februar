import { ObjectId } from "mongodb";
import mongoose from "mongoose";
const Schema = mongoose.Schema;

let User = new Schema({
    type: String,
    firstname: String,
    lastname: String,
    username: String,
    password: String,
    phone: String,
    email: String,
    picture: String,
    status: String,

    company: String,
    address: String,
    maticni: Number,
    pib: Number,

    token: String,
    tokenExpiration: Date
})

export default mongoose.model("UserModel", User, "user");