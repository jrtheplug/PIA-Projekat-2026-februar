import mongoose from "mongoose";
import user from "./user";
import { ObjectId } from "mongodb";
const Schema = mongoose.Schema;

let Reservation = new Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'UserModel'  
    },
    space: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'SpaceModel'  
    },
    from: {type: Date},
    to:  {type: Date},
    type: String,
    status: String,
    showed: String,
    name: String
})

export default mongoose.model("ReservationModel", Reservation, "reservations");