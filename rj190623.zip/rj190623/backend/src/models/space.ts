import mongoose from "mongoose";
import user from "./user";
import { identity } from "@fullcalendar/core/internal";
import { ObjectId } from "mongodb";
const Schema = mongoose.Schema;

let Space = new Schema({

    name: String,
    city: String,
    address: String,
    company: String,
    manager: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'UserModel'  
    },
    pictures: {
        type: Array
    },
    likes: {
        type: Number,
        default: 0
    },
    dislikes: {
        type: Number,
        default: 0
    },
    location: String,
    openSpace: Number,
    offices:{
        type: Array
    },
    confs: {
        type: Array
    },
    comments: {
        type: Array
    },
    ban: Number,
    status: String,
    price: Number
})

export default mongoose.model("SpaceModel", Space, "spaces");