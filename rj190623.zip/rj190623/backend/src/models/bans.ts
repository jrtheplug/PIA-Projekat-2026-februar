import mongoose from "mongoose";
import user from "./user";
import { ObjectId } from "mongodb";
const Schema = mongoose.Schema;

let Bans = new Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'UserModel'  
    },
    space: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'SpaceModel'  
    },
    strikes: {
        type: Number,
        default: 0
    }
})

export default mongoose.model("BansModel", Bans, "bans");