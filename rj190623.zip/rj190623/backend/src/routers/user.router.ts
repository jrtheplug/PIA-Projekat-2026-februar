import express from 'express'
import { UserController } from '../controllers/user.controller';

const userRouter = express.Router()

userRouter.route("/login").post(
    (req, res) => new UserController().login(req, res)
)

userRouter.route("/register").post(
    (req, res) => new UserController().register(req, res)
)

userRouter.route("/registerM").post(
    (req, res) => new UserController().registerM(req, res)
)

userRouter.route("/allUsersNA").get(
    (req, res) => new UserController().allUsersNA(req, res)
)

userRouter.route("/denyU").post(
    (req, res) => new UserController().denyU(req, res)
)

userRouter.route("/acceptU").post(
    (req, res) => new UserController().acceptU(req, res)
)

userRouter.route("/updateUser").post(
    (req, res) => new UserController().updateUser(req, res)
)

userRouter.route("/deleteUser").post(
    (req, res) => new UserController().deleteUser(req, res)
)

userRouter.route("/userByID").post(
    (req, res) => new UserController().userByID(req, res)
)

userRouter.route("/forgotPassword").post(
    (req, res) => new UserController().forgotPassword(req, res)
)

userRouter.route("/resetPassword").post(
    (req, res) => new UserController().resetPassword(req, res)
)

userRouter.route("/allUsers").get(
    (req, res) => new UserController().allUsers(req, res)
)

export default userRouter;