import express from 'express'
import { SpaceController } from '../controllers/space.controller';

const spaceRouter = express.Router()

spaceRouter.route("/allcities").get(
    (req, res) => new SpaceController().allCities(req, res)
)

spaceRouter.route("/search").post(
    (req, res) => new SpaceController().search(req, res)
)

spaceRouter.route("/top").get(
    (req, res) => new SpaceController().top(req, res)
)

spaceRouter.route("/like").post(
    (req, res) => new SpaceController().like(req, res)
)

spaceRouter.route("/dislike").post(
    (req, res) => new SpaceController().dislike(req, res)
)

spaceRouter.route("/allComments").post(
    (req, res) => new SpaceController().allComments(req, res)
)

spaceRouter.route("/spacesByManagerCompany").post(
    (req, res) => new SpaceController().spacesByManagerCompany(req, res)
)

spaceRouter.route("/addSpace").post(
    (req, res) => new SpaceController().addSpace(req, res)
)

spaceRouter.route("/addOffice").post(
    (req, res) => new SpaceController().addOffice(req, res)
)

spaceRouter.route("/addConf").post(
    (req, res) => new SpaceController().addConf(req, res)
)

spaceRouter.route("/addStrike").post(
    (req, res) => new SpaceController().addStrike(req, res)
)

spaceRouter.route("/allSpacesNA").get(
    (req, res) => new SpaceController().allSpacesNA(req, res)
)

spaceRouter.route("/denyS").post(
    (req, res) => new SpaceController().denyS(req, res)
)

spaceRouter.route("/acceptS").post(
    (req, res) => new SpaceController().acceptS(req, res)
)

spaceRouter.route("/addComment").post(
    (req, res) => new SpaceController().addComment(req, res)
)

export default spaceRouter;