import express from 'express'
import { ReservationController } from '../controllers/reservation.controller';

const resrvationRouter = express.Router()

resrvationRouter.route("/bySpace").post(
    (req, res) => new ReservationController().reservationsBySpace(req, res)
)

resrvationRouter.route("/byUser").post(
    (req, res) => new ReservationController().reservationsByUser(req, res)
)

resrvationRouter.route("/byManager").post(
    (req, res) => new ReservationController().reservationsByManager(req, res)
)

resrvationRouter.route("/byElement").post(
    (req, res) => new ReservationController().reservationsByElement(req, res)
)

resrvationRouter.route("/cancel").post(
    (req, res) => new ReservationController().cancel(req, res)
)

resrvationRouter.route("/showed").post(
    (req, res) => new ReservationController().showed(req, res)
)

resrvationRouter.route("/between").post(
    (req, res) => new ReservationController().between(req, res)
)

resrvationRouter.route("/changeReservationTime").post(
    (req, res) => new ReservationController().changeReservationTime(req, res)
)

resrvationRouter.route("/addReservation").post(
    (req, res) => new ReservationController().addReservation(req, res)
)
export default resrvationRouter;