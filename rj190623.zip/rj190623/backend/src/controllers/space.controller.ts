import express from 'express'
import UserModel from '../models/user'
import SpaceModel from '../models/space'
import BansModel from '../models/bans'
import space from '../models/space'

export class SpaceController {

    allCities = (req: express.Request, res: express.Response) => {
        SpaceModel.find({"status": "A"}).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Spaces not found");
            res.json(null);
        })
    }

    search = (req: express.Request, res: express.Response) => {
        let name = req.body.name;
        let city = req.body.city;
        //console.log(name);
        const filter: any = {};

        if (name) {
            filter.name = {
                $regex: name,
                $options: 'i'   // case insensitive
            }

        }
        if (city) {
            filter.city = city;
        }

        filter.status = "A";

        SpaceModel.find(filter).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Spaces not found");
            res.json(null);
        })
    }

    top = (req: express.Request, res: express.Response) => {

        SpaceModel.find({"status": "A"}).sort({ likes: -1 }).limit(5).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Top 5 error");
            res.json(null);
        })
    }

    like = (req: express.Request, res: express.Response) => {
        let space = req.body;
        //console.log(space._id);
        SpaceModel.findOneAndUpdate({ "_id": space._id }, { "likes": space.likes + 1 }, { new: true }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Like error");
            res.json(null);
        })
    }

    dislike = (req: express.Request, res: express.Response) => {
        let space = req.body;

        SpaceModel.findOneAndUpdate({ "_id": space._id }, { "dislikes": space.dislikes + 1 }, { new: true }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Dislike error");
            res.json(null);
        })
    }

    allComments = (req: express.Request, res: express.Response) => {
        let space = req.body;

        SpaceModel.find({ "_id": space._id }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Comments error");
            res.json(null);
        })
    }

    spacesByManagerCompany = (req: express.Request, res: express.Response) => {
        let user = req.body.user;
        //console.log(user._id);
        SpaceModel.find({ "manager": user._id , "status": "A"}).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Spaces by manager error");
            res.json(null);
        })
    }


    addSpace = async (req: express.Request, res: express.Response) => {
        try {
            //console.log("BODY:", req.body);
            const data = { ...req.body };

            delete data._id; // 🔥 OBRIŠI ID

            const men = new UserModel(data.manager);
            //console.log(JSON.stringify(men));

            data.manager = men;
            const novi = new SpaceModel({ "name": data.name, "city": data.city, "address": data.address, "company": data.company, "openSpace": data.openSpace, "manager": men, "status": data.status, "price": data.price });
            //novi.manager = men;
            //console.log(JSON.stringify(novi.manager));
            const saved = await novi.save();

            //console.log("SAVED:", saved);

            res.status(201).json(saved);
        } catch (err) {
            console.log("ERROR:", err);
            res.status(500).json(err);
        }
    }

    addOffice = (req: express.Request, res: express.Response) => {
        let space = req.body;

        SpaceModel.findOneAndUpdate({ "_id": space._id }, { "offices": space.offices }, { new: true }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Add office error");
            res.json(null);
        })
    }

    addConf = (req: express.Request, res: express.Response) => {
        let space = req.body;

        SpaceModel.findOneAndUpdate({ "_id": space._id }, { "confs": space.confs }, { new: true }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Add conf error");
            res.json(null);
        })
    }

    addStrike = async (req: express.Request, res: express.Response) => {
        let space = req.body.space;
        let user = req.body.user;
        let strikes = 0;
        BansModel.findOne({ "space._id": space._id, "user._id": user._id }).then((ban) => {
            if (ban) {
                BansModel.findOneAndUpdate({ "space._id": space._id, "user._id": user._id }, { "strikes": ban.strikes + 1 }, { new: true }).then((all) => {
                    res.json(all);
                }).catch(() => {
                    console.log("Add strike error");
                    res.json(null);
                })
            }

        }).catch(() => {
            console.log("Add strike 2 error");
            res.json(null);
        })

    }

    allSpacesNA = (req: express.Request, res: express.Response) => {

        SpaceModel.find({ "status": "N" }).then((spaces) => {
            res.json(spaces);
        }).catch(() => {
            console.log("Spaces NA error");
            res.json(null);
        })
    }

    denyS = (req: express.Request, res: express.Response) => {
        let space = req.body;

        SpaceModel.findOneAndUpdate({"_id": space._id},{ "status": "D" }).then((spaces) => {
            res.json(spaces);
        }).catch(() => {
            console.log("Spaces NA error");
            res.json(null);
        })
    }

    acceptS = (req: express.Request, res: express.Response) => {
        let space = req.body;

        SpaceModel.findOneAndUpdate({"_id": space._id},{ "status": "A" }).then((spaces) => {
            res.json(spaces);
        }).catch(() => {
            console.log("Spaces NA error");
            res.json(null);
        })
    }

    addComment = (req: express.Request, res: express.Response) => {
        let space = req.body;

        SpaceModel.findOneAndUpdate({"_id": space._id},{ "comments": space.comments }).then((spaces) => {
            res.json(spaces);
        }).catch(() => {
            console.log("Add comment error");
            res.json(null);
        })
    }

}