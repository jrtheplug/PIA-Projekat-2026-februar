import express from 'express'
import UserModel from '../models/user'
import SpaceModel from '../models/space'
import ReservationModel from '../models/reservations'
import { start } from 'repl'

export class ReservationController {

    reservationsBySpace = (req: express.Request, res: express.Response) => {
        let space = req.body.space;

        const filter: any = {};
        filter.space = req.body.space;
        //console.log(space.name);
        ReservationModel.find({ "space": space._id }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Resrvation by Space error");
            res.json(null);
        })
    }

    reservationsByUser = (req: express.Request, res: express.Response) => {
        let user = req.body.user;

        const filter: any = {};
        filter.space = req.body.space;
        //console.log(user._id);
        ReservationModel.find({ "user": user._id , "status": "A"}).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Resrvation by User error");
            res.json(null);
        })
    }

    reservationsByManager = (req: express.Request, res: express.Response) => {
        let men = req.body.manager;

        //console.log(men.name);

        ReservationModel.find({ "space.manager": men._id }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Resrvation by manager error");
            res.json(null);
        })
    }

    reservationsByElement = (req: express.Request, res: express.Response) => {
        let name = req.body.name;
        let space = req.body.space;
        if (name == "") {
            //console.log("da");
            ReservationModel.find({ "type": "openSpace", "space": space._id }).then((all) => {
                res.json(all);
            }).catch(() => {
                console.log("Resrvation by Element error");
                res.json(null);
            })
        } else {
            //console.log(men.name);
            ReservationModel.find({ "name": name, "space": space._id }).then((all) => {
                res.json(all);
            }).catch(() => {
                console.log("Resrvation by Element error");
                res.json(null);
            })
        }


    }

    cancel = (req: express.Request, res: express.Response) => {
        let reservation = req.body.reservation;

        ReservationModel.findOneAndUpdate({ "_id": reservation._id }, { $set: { status: "C" } }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Resrvation cancel error");
            res.json(null);
        })
    }

    showed = (req: express.Request, res: express.Response) => {
        let reservation = req.body.reservation;
        let show = req.body.showed;

        if (show) {
            ReservationModel.findOneAndUpdate({ "_id": reservation._id }, { $set: { showed: "T" } }).then((all) => {
                res.json(all);
            }).catch(() => {
                console.log("Showed true error");
                res.json(null);
            })
        } else {
            ReservationModel.findOneAndUpdate({ "_id": reservation._id }, { $set: { showed: "F" } }).then((all) => {
                res.json(all);
            }).catch(() => {
                console.log("Showed false error");
                res.json(null);
            })
        }



    }

    between = (req: express.Request, res: express.Response) => {
        let space = req.body.space;
        let start = new Date(req.body.start);
        let end = new Date(req.body.end);
        let name1 = req.body.name;
        //console.log(start);
        //console.log(end);
        ReservationModel.find({ "space": space._id, "name": name1, "from": { $gte: start, $lt: end } }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Between error");
            res.json(null);
        })
    }

    changeReservationTime = (req: express.Request, res: express.Response) => {
        let reservation = req.body;

        let start = new Date(reservation.from);
        let end = new Date(reservation.to);

        //console.log(start);
        //console.log(reservation.from);
        //console.log(end);
        ReservationModel.findOneAndUpdate({ "_id": reservation._id }, { $set: { "from": start, "to": end } }).then((all) => {
            res.json(all);
        }).catch(() => {
            console.log("Change reservation time error");
            res.json(null);
        })
    }

    addReservation = async (req: express.Request, res: express.Response) => {
        try {
            const data = { ...req.body };

            delete data._id; 

            const user = new UserModel(data.user);
            //console.log(JSON.stringify(men));
            const space = new SpaceModel(data.space);
            
            const novi = new ReservationModel({ "name": data.name, "user": user, "space": space, "from": data.from, "to": data.to, "type": data.type, "status": data.status });
            //novi.manager = men;
            //console.log(JSON.stringify(novi.manager));
            const saved = await novi.save();

            //console.log("SAVED:", saved);

            res.status(201).json(saved);
        } catch (err) {
            console.log("ADD RESERVATION ERROR:", err);
            res.status(500).json(err);
        }
    }
}