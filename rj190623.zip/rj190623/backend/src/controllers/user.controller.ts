import express from 'express'
import UserModel from '../models/user'
import bcrypt from 'bcryptjs'
import crypto from "crypto";

export class UserController {

    saltRounds = 12;

    login = async (req: express.Request, res: express.Response) => {
        let username = req.body.username;
        let password = req.body.password;

        const user = await UserModel.findOne({ username: username, "status": "A" });

        if (!user || !user.password) {
            return res.json("User not found");
        }

        const check = await bcrypt.compare(password, user.password);

        if (!check) {
            return res.json("Pogresan password");
        }
        res.json(user);
        //console.log("User not found");

    }

    register = async (req: express.Request, res: express.Response) => {
        try {
            let type = req.body.type
            let username = req.body.username
            let password = req.body.password
            let firstname = req.body.firstname
            let lastname = req.body.lastname
            let phone = req.body.phone
            let email = req.body.email
            let picture = req.body.picture
            let firma = req.body.company
            let adresa = req.body.address
            let maticni = req.body.maticni
            let pib = req.body.pib

            const hashedPassword = await bcrypt.hash(req.body.password, this.saltRounds);

            const u = new UserModel({
                type: type, firstname: firstname, lastname: lastname,
                username: username, password: hashedPassword, phone: phone, email: email, picture: picture, status: "N"
            });

            await u.save();
            res.json({ "message": "User added" });

        } catch (err) {
            console.log("Adding user error" + err);
            res.json({ "message": "Error" });
        }
    }


    registerM = async (req: express.Request, res: express.Response) => {
        try {
            let type = req.body.type
            let username = req.body.username
            let password = req.body.password
            let firstname = req.body.firstname
            let lastname = req.body.lastname
            let phone = req.body.phone
            let email = req.body.email
            let picture = req.body.picture
            let firma = req.body.company
            let adresa = req.body.address
            let maticni = req.body.maticni
            let pib = req.body.pib

            const hashedPassword = await bcrypt.hash(req.body.password, this.saltRounds);

            const u = new UserModel({
                type: type, firstname: firstname, lastname: lastname,
                username: username, password: hashedPassword, phone: phone, email: email, picture: picture, company: firma, address: adresa, maticni: maticni, pib: pib, status: "N"
            });

            await u.save();
            res.json({ "message": "User added" });

        } catch (err) {
            console.log("Adding user error" + err);
            res.json({ "message": "Error" });
        }
    }


    allUsersNA = (req: express.Request, res: express.Response) => {

        UserModel.find({ "status": "N" }).then((user) => {
            res.json(user);
        }).catch(() => {
            console.log("Users NA error");
            res.json(null);
        })
    }

    denyU = (req: express.Request, res: express.Response) => {
        let user = req.body;

        UserModel.findOneAndUpdate({ "_id": user._id }, { "status": "D" }).then((user) => {
            res.json(user);
        }).catch(() => {
            console.log("Deny user error");
            res.json(null);
        })
    }

    acceptU = (req: express.Request, res: express.Response) => {
        let user = req.body;

        UserModel.findOneAndUpdate({ "_id": user._id }, { "status": "A" }).then((user) => {
            res.json(user);
        }).catch(() => {
            console.log("Deny user error");
            res.json(null);
        })
    }

    updateUser = async (req: express.Request, res: express.Response) => {
        let user = req.body;
        const data = { ...req.body };

        delete data._id;

        const hashedPassword = await bcrypt.hash(user.password, this.saltRounds);
        data.password = hashedPassword;

        await UserModel.findOneAndUpdate({ "_id": user._id }, data).then((user) => {
            res.json(user);
        }).catch(() => {
            console.log("Update user error");
            res.json(null);
        })
    }

    deleteUser = (req: express.Request, res: express.Response) => {
        let user = req.body;

        UserModel.findOneAndDelete({ "_id": user._id }).then((user) => {
            res.json(user);
        }).catch(() => {
            console.log("Delete user error");
            res.json(null);
        })
    }

    userByID = (req: express.Request, res: express.Response) => {
        let index = req.body.index;
        console.log(index);
        UserModel.findOne({ "_id": index }).then((user) => {
            res.json(user);
        }).catch(() => {
            console.log("Find user by ID error");
            res.json(null);
        })
    }

    allUsers = (req: express.Request, res: express.Response) => {

        UserModel.find({}).then((users) => {
            res.json(users);
        }).catch(() => {
            console.log("Find user by ID error");
            res.json(null);
        })
    }


    forgotPassword = async (req: express.Request, res: express.Response) => {
        let username = req.body.username;
        //console.log(req.body.username);

        //console.log(JSON.stringify(username));

        let user = await UserModel.findOne({ "username": username });
        if(!user)   user = await UserModel.findOne({ "email": username });
        //console.log(user.username);
        if (!user) return res.json("NO user");

        const token = crypto.randomBytes(32).toString("hex");
        user.token = token;
        user.tokenExpiration = new Date(Date.now() + 30 * 60 * 1000);

        await user.save();

        res.json(token);
    }

    resetPassword = async (req: express.Request, res: express.Response) => {
        let token = req.body.token;
        let novi = req.body.password;


        const user = await UserModel.findOne({ "token": token , "tokenExpiration": {$gt: new Date()}});
        if (!user) return res.json("Session expired");

        const hashedPassword = await bcrypt.hash(novi, this.saltRounds);
        user.password = hashedPassword;
        user.token = undefined;
        user.tokenExpiration = undefined;

        await user.save();


        res.json("Reset password succesfull!");
    }
}