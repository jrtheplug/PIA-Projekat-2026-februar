import express from 'express'
import cors from 'cors'
import mongoose from 'mongoose'
import userRouter from './routers/user.router'
import spaceRouter from './routers/space.router'
import reservationRouter from './routers/reservation.router'

const app = express()
app.use(cors())
app.use(express.json({ limit: "10mb" }));

mongoose.connect("mongodb://127.0.0.1:27017/projekat");

const connection = mongoose.connection;
connection.once("open", () => {
    console.log("Connected to MongoDB on port 27017");
})

const router = express.Router()
router.use("/users", userRouter)
router.use("/spaces", spaceRouter)
router.use("/reservations", reservationRouter)
console.log("rebuild");
app.use("/", router)
app.listen(4000, ()=>console.log("Express running on port 4000!"))