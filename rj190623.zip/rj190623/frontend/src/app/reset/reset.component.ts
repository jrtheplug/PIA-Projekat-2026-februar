import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reset',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './reset.component.html',
  styleUrl: './reset.component.css'
})
export class ResetComponent {
  newPassword = "";
  token = "";
  private userService = inject(UserService);
  private router = inject(Router);


  ngOnInit(): void{
    this.token = localStorage.getItem("token")!
  }

  reset(){
    this.userService.resetPassword(this.token, this.newPassword).subscribe((cnf) => {
      alert(cnf);
      this.router.navigate(["login"]);
    })
  }
}
