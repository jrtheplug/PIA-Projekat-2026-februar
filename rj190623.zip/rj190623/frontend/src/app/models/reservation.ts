import { SpaceType } from "./space";
import { UserType } from "./user";

export class ReservationType{
    _id = ""
    user: UserType = new UserType()
    space: SpaceType = new SpaceType()
    from: Date = new Date()
    to: Date = new Date()
    type = ""
    status = ""
    showed = ""
    name = ""
}