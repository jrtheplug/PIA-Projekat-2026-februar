export class Comments{
    username = ""
    datum: Date = new Date()
    text = ""
}