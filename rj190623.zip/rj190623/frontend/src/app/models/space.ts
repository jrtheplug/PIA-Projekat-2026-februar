import { Comments } from "./comments"
import { Conf } from "./conf"
import { Office } from "./office"
import { UserType } from "./user"

export class SpaceType {
    _id = ""
    name = ""
    city = ""
    address = ""
    company = ""
    manager : UserType = new UserType()
    likes = 0
    dislikes = 0
    pictures : string[] = []
    location = ""
    openSpace = 0
    offices: Office[] = [];
    confs: Conf[] = [];
    comments: Comments[] = [];
    ban = -1
    status = ""
    price = 0
}