export class Conf{
    name = ""
    description = ""
}