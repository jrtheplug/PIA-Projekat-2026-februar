export class Office{
    name = ""
    size = 0
}