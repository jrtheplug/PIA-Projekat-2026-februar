import { SpaceType } from "./space";
import { UserType } from "./user";

export class BansType{
    user: UserType = new UserType();
    space: SpaceType = new SpaceType();
    strikes = 0
}