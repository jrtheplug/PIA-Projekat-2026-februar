export class UserType {
    _id = ""
    type = ""
    username = ""
    password = ""
    firstname = ""
    lastname = ""
    phone = ""
    email = ""
    status = ""
    picture = ""
    company = ""
    address = ""
    maticni = -1
    pib = -1
}