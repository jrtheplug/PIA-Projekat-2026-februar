import { Component, inject } from "@angular/core";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { SpaceService } from "../services/space.service";
import { SpaceType } from "../models/space";
import { ReservationType } from "../models/reservation";
import { ReservationService } from "../services/reservation.service";
import { UserType } from "../models/user";
import { forkJoin, map, switchMap } from "rxjs";

@Component({
  selector: 'app-pdf-generator',
  standalone: true,
  imports: [],
  templateUrl: './pdf-generator.component.html',
  styleUrl: './pdf-generator.component.css'
})
export class PdfGeneratorComponent {

  private spaceService = inject(SpaceService);
  private reservationService = inject(ReservationService);
  searchList: SpaceType[] = [];
  reservationList: ReservationType[] = [];
  user: UserType = new UserType();
  month = 0
  filledSpacesOffice: Map<string, number> = new Map();
  filledSpacesConf: Map<string, number> = new Map();

  podaci() {
    this.user = JSON.parse(localStorage.getItem("manager")!);
    this.month = JSON.parse(localStorage.getItem("month")!);

    let brojTermina = 24 * 31;
    let startDate = new Date(2026, this.month - 1, 1, 0, 0, 0);
    let endDate = new Date(2026, this.month, 1, 0, 0, 0);

    return this.spaceService.allCities().pipe(

      switchMap(spaces => {

        const requests: any[] = [];
        const meta: any[] = [];

        spaces.forEach(space => {

          space.offices.forEach(office => {
            requests.push(
              this.reservationService.reservationsBetween(
                space, startDate, endDate, office.name
              )
            );

            meta.push({
              type: "Office",
              label: `${space.name} - ${office.name}`
            });
          });

          space.confs.forEach(conf => {
            requests.push(
              this.reservationService.reservationsBetween(
                space, startDate, endDate, conf.name
              )
            );

            meta.push({
              type: "Conference",
              label: `${space.name} - ${conf.name}`
            });
          });

        });

        return forkJoin(requests).pipe(

          map(results => {

            return results.map((rez, index) => ({
              rb: index + 1,
              type: meta[index].type,
              name: meta[index].label,
              fill: rez.length / brojTermina * 100
            }));

          })

        );

      })

    );
  }


  generatePDF() {
    this.podaci().subscribe((done) => {
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text("Popunjenost po prostorima", 10, 10);
      doc.setFontSize(12);
      doc.text("This is a comprehensive guide on generating PDFs with Angular.", 10, 20);
      const headers = [["INDEX", "Type", "Name", "Fullfilment %"]];
      //const data = [{name: "pera", fill: 0}];

      //const data = Array.from(this.filledSpacesOffice, ([name, fill]) => ({
        //name,
        //fill
      //}));
      //alert(JSON.stringify(this.filledSpacesOffice));
      //const rowData = Array.from(this.filledSpacesOffice, ([name, fill], index) => [
      //(index + 1).toString(),
      //name,
      //fill.toString()
      //]);

      done.sort((a, b) => b.fill - a.fill);
      const rowData = done.map(item => [
        item.rb.toString(),
        item.type,
        item.name,
        item.fill.toFixed(3)
      ]);
      alert(JSON.stringify(rowData));
      autoTable(doc, {
        head: headers,
        body: rowData,
        startY: 30,
      });
      doc.save("report.pdf");
    })

  }

}
