import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDetaljComponent } from './admin-detalj.component';

describe('AdminDetaljComponent', () => {
  let component: AdminDetaljComponent;
  let fixture: ComponentFixture<AdminDetaljComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminDetaljComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminDetaljComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
