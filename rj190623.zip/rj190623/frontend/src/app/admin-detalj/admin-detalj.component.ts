import { Component, inject } from '@angular/core';
import { UserType } from '../models/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-detalj',
  standalone: true,
  imports: [],
  templateUrl: './admin-detalj.component.html',
  styleUrl: './admin-detalj.component.css'
})
export class AdminDetaljComponent {

  user: UserType = new UserType();
  private router = inject(Router);

  ngOnInit(): void{
    this.user = JSON.parse(localStorage.getItem("detaljniKorisnik")!)
  }

  back(){
    this.router.navigate(["admin"]);
  }
}
