import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { PocetnaComponent } from './pocetna/pocetna.component';
import { DetaljComponent } from './detalj/detalj.component';
import { ProfilComponent } from './profil/profil.component';
import { MenagerComponent } from './menager/menager.component';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';
import { AdminDetaljComponent } from './admin-detalj/admin-detalj.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetComponent } from './reset/reset.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';

export const routes: Routes = [
    {path: "", component: PocetnaComponent},
    {path: "login", component: LoginComponent},
    {path: "register", component: RegisterComponent},
    {path: "details", component: DetaljComponent},
    {path: "profil", component: ProfilComponent},
    {path: "menager", component: MenagerComponent},
    {path: "admin", component: AdminPanelComponent},
    {path: "adminLogin", component: AdminLoginComponent},
    {path: "detaljiOKorisniku", component: AdminDetaljComponent},
    {path: "forgot", component: ForgotPasswordComponent},
    {path: "reset", component: ResetComponent}
];
