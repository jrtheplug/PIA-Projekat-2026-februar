import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UserType } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  username = ""
  password = ""
  user: UserType = new UserType();

  private router = inject(Router);
  private userService = inject(UserService);

  login() {
    this.userService.
      login(this.username, this.password).subscribe((all) => {
        if (all.firstname) {
          alert("Login succesfull");
          this.user = all;
          localStorage.setItem("loggedUser", JSON.stringify(this.user));
          if(this.user.type == "Clan mreze"){
            this.router.navigate(["/profil"]);
          }
          else if(this.user.type == "Menadzer prostora"){
            localStorage.setItem("manager", JSON.stringify(this.user));
            this.router.navigate(["/menager"]);
          }
        }
        else {
          alert("No user")
        }
      })

  }
}
