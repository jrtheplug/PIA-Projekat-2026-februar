import { Component, inject } from '@angular/core';
import { UserType } from '../models/user';
import { SpaceType } from '../models/space';
import { Router, RouterLink } from '@angular/router';
import { SpaceService } from '../services/space.service';
import { FormsModule } from '@angular/forms';
import { ReservationService } from '../services/reservation.service';
import { ReservationType } from '../models/reservation';
import { CommonModule, DatePipe } from '@angular/common';
import { Calendar, CalendarOptions } from '@fullcalendar/core';
import { FullCalendarComponent, FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin, { DateClickArg } from '@fullcalendar/interaction';
import { PdfGeneratorComponent } from '../pdf-generator/pdf-generator.component';
import { UserService } from '../services/user.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-profil',
  standalone: true,
  imports: [FormsModule, DatePipe, FullCalendarModule, CommonModule, PdfGeneratorComponent, RouterLink],
  templateUrl: './menager.component.html',
  styleUrl: './menager.component.css'
})
export class MenagerComponent {

  searchList: SpaceType[] = [];
  spaceList: SpaceType[] = [];
  user: UserType = new UserType();
  reservationList: ReservationType[] = [];
  private userService = inject(UserService)
  private spaceService = inject(SpaceService);
  private reservationService = inject(ReservationService);
  private router = inject(Router);

  firstname = ""
  lastname = ""
  email = ""
  phone = ""
  password = ""
  file!: File;
  firma = ""
  address = ""
  maticni = 0
  pib = 0
  imageBase64!: string;


  officesList: string[] = [];
  confsList: string[] = [];
  naziv = "";
  kompanija = "";
  brStolva = 0;
  grad = "";
  adresa = "";
  cena = 0;
  brStolovaKanc = 0;
  kancNaziv = "";
  nazivKonf = "";
  opisKonf = "";
  newSpace: SpaceType = new SpaceType();

  prostor = ""
  element = ""
  selectedProstor: SpaceType = new SpaceType();
  selectedElementReservations: ReservationType[] = [];

  fileContent: string = '';
  fileSpace: SpaceType = new SpaceType();



  calendarOptions: CalendarOptions = {
    initialView: 'timeGridWeek',
    plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
    timeZone: 'UTC',
    editable: true,
    dateClick: (arg) => this.handleDateClick(arg),
    eventDrop: this.handleEventDrop.bind(this),
    events: []
  };

  handleDateClick(arg: DateClickArg) {
    //alert('date click! ' + arg.dateStr)
  }

  handleDatesSet(dateInfo: { start: Date; end: Date; startStr: string; endStr: string; timeZone: string; view: any }): void {
    const currentMonth = dateInfo.start.getMonth() + 1; 
    //console.log('Current month:', currentMonth);
    
  }

  handleEventDrop(info: any) {

    //console.log('Event dropped on ' + info.event.start + info.event.end + info.event.id);

    let res = new ReservationType();
    this.reservationList.forEach((r) => {
      console.log(r._id);
      if (r._id.match(info.event.id)) {
        res = r;
      }
    })
    res.from = new Date(info.event.start);
    res.to = new Date(info.event.end);

    //console.log(JSON.stringify(res));

    this.reservationService.changeReservationTime(res).subscribe((newRes) => {
      this.reservationList.forEach((r) => {
        if (res._id.match(r._id)) {
          r = newRes;
        }

      })
      alert("Promenjena rezervacija");
    })

    // info.revert();
  }

  onSelectChangeProstor() {
    this.spaceService.search(this.prostor, "").subscribe((all) => {
      //alert(JSON.stringify(all[0]));
      this.selectedProstor = all[0];
    })

  }

  onFileSelected(event: any) {
    const img: File = event.target.files[0];

    if (img) {
      this.file = img;

      const reader = new FileReader();
      reader.readAsDataURL(img);

      reader.onload = () => {
        this.imageBase64 = reader.result as string;
        console.log(this.imageBase64);
      };
    }
  }

  events: any[] = [];
  dates: number[] = [];
  onSelectChangeElement() {
    this.selectedElementReservations = [];
    this.events = [];
    //alert(this.element);
    if (this.element.match("otvoreni prostor")) {
      this.element = ""
      //alert("DA");
    }
    this.reservationService.reservationsByElement(this.selectedProstor, this.element).subscribe((all) => {
      console.log(JSON.stringify(all));
      this.selectedElementReservations = all;
      //alert(JSON.stringify(all));
      //console.log(JSON.stringify(all));

      this.selectedElementReservations.forEach(e => {
        //alert(JSON.stringify(e));
        //alert(JSON.stringify(e.from));
        //alert(this.reservationList[0].from.getFullYear())
        let date = new Date(e.from);
        this.dates.push(date.getDate());
        this.events.push({ id: e._id, title: e.name, start: e.from, end: e.to })


        //alert(date.getDate());
      })
      this.calendarOptions.events = this.events;
    })
    localStorage.setItem("month", JSON.stringify(new Date().getMonth() + 1))
  }

  public onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file: File = input.files[0];
      const fileReader: FileReader = new FileReader();

  
      fileReader.onload = (e) => {

        this.fileContent = fileReader.result as string;
        this.fileSpace = JSON.parse(this.fileContent);
        //alert(this.fileSpace.name);
        //console.log('File Content:', this.fileContent);


      };
      fileReader.readAsText(file);


    }
  }
  userMap: { [key: string]: UserType } = {};
  spaceMap: { [key: string]: SpaceType } = {};

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("loggedUser")!);
    this.maticni = this.user.maticni;
    this.pib = this.user.pib;
    //console.log(JSON.stringify(this.user));

    this.spaceService.allCities().subscribe((all) => {
      this.searchList = all;
    })

    this.spaceService.spacesByManagerCompany(this.user).subscribe((all) => {
      this.spaceList = all;

      let rezervacije: ReservationType[] = [];
      this.spaceList.forEach(space => {
        //console.log(JSON.stringify(space));
        this.reservationService.reservationsSpace(space).subscribe((res) => {
          //console.log(JSON.stringify(res));
          res.forEach(r => {
            rezervacije.push(r);
            this.reservationList = rezervacije;
            //console.log(JSON.stringify(this.reservationList));
          })
        })


      })

      //console.log(JSON.stringify(this.spaceList));
    })


    this.userService.allUsers().subscribe((users) => {
      users.forEach(u => {
        this.userMap[u._id] = u;
      })
      console.log(JSON.stringify(this.userMap));
    })

    this.spaceService.allCities().subscribe((spaces) => {
      spaces.forEach(s => {
        this.spaceMap[s._id] = s;
      })
      console.log(JSON.stringify(this.spaceMap));
    })

  }

  passwordRegex: RegExp =
    /^[A-Za-z](?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,12}$/;

  emailRegex: RegExp = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  maticniRegex: RegExp = /^\d{8}$/;

  pibRegex: RegExp = /^[1-9]\d{8}$/;

  isValidPassword(password: string): boolean {
    return this.passwordRegex.test(password);
  }

  isValidEmail(email: string): boolean {
    return this.emailRegex.test(email);
  }

  isValidMaticni(maticni: number): boolean {
    return this.maticniRegex.test(maticni.toString());
  }

  isValidPIB(pib: number): boolean {
    return this.pibRegex.test(pib.toString());
  }

  updateUser() {
    let newUser = this.user;
    if (!this.user.firstname.match(this.firstname)) {
      newUser.firstname = this.firstname;
    }
    if (!this.user.lastname.match(this.lastname)) {
      newUser.lastname = this.lastname;
    }
    if (!this.user.email.match(this.email)) {
      if (this.isValidEmail(this.email)) {
        newUser.email = this.email;
      } else {
        alert("Neispravan email");
      }

    }
    if (!this.user.phone.slice(1,).match(this.phone.slice(1,))) {
      newUser.phone = this.phone;
    }
    if (this.password.length != 0) {
      //alert(this.password);
      if (this.isValidPassword(this.password)) {
        newUser.password = this.password;
      }
      else {
        alert("Neispravan password");
      }

    }

    if (this.imageBase64 != null) {
      //alert("Da");
      newUser.picture = this.imageBase64;
    }

    if (!this.user.company.match(this.firma)) {
      newUser.company = this.firma;
    }
    if (!this.user.address.match(this.address)) {
      newUser.address = this.address;
    }
    if (this.user.maticni != this.maticni) {
      if (this.isValidMaticni(this.maticni)) {
        newUser.maticni = this.maticni;
      } else {
        alert("Neispravan maticni");
      }

    }
    if (this.user.pib != this.pib) {
      if (this.isValidPIB(this.pib)) {
        newUser.pib = this.pib;
      } else {
        alert("Neispravan pib");
      }
    }
    alert(this.lastname);
    this.userService.updateUser(newUser).subscribe((cnf) => {
      this.user = cnf;
      alert("User updated!");
    })

  }

  showOffices(space: SpaceType) {
    this.officesList = [];
    space.offices.forEach(o => {
      this.officesList.push(o.name);
    })
    return this.officesList;
  }

  showConfs(space: SpaceType) {
    this.confsList = [];
    space.confs.forEach(c => {
      this.confsList.push(c.name);
    })
    return this.confsList;
  }

  addSpace() {
    if (this.brStolva < 5) {
      alert("Broj stolova u otvorenom prostoru mora biti veci od 5")
      return;
    }

    let space = new SpaceType();
    space.name = this.naziv;
    space.company = this.kompanija;
    space.openSpace = this.brStolva;
    space.manager = this.user;
    space.address = this.adresa;
    space.city = this.grad;
    space.status = "N";
    space.price = this.cena;
    //alert(this.user.username);
    this.spaceService.addSpace(space).subscribe((all) => {
      this.newSpace = all;
      alert("Space added");
    })
  }

  addSpaceFile() {

    this.spaceService.addSpace(this.fileSpace).subscribe((all) => {
      //this.newSpace = all;
      alert("Space added true file");
    })
  }

  isUnique(naziv: string) {
    let cnf = true;
    this.newSpace.offices.forEach(o => {
      if (o.name == naziv)
        cnf = false;
    })
    this.newSpace.confs.forEach(c => {
      if (c.name == naziv)
        cnf = false;
    })
    return cnf;
  }

  addOffice() {
    if (!this.isUnique(this.kancNaziv)) {
      alert("Naziv kancelarije je zauzet!");
      return;
    }
    else {
      let office = {
        name: this.kancNaziv,
        size: this.brStolovaKanc
      }
      this.newSpace.offices.push(office);
      this.spaceService.addOffice(this.newSpace).subscribe((all) => {
        this.newSpace = all;
        alert("Office added");
      })
      //alert(JSON.stringify(this.newSpace));
    }

  }

  addConf() {
    if (!this.isUnique(this.nazivKonf)) {
      alert("Naziv konfenecijske sale je zauzet!");
      return;
    }
    else {
      let conf = {
        name: this.nazivKonf,
        description: this.opisKonf
      }
      this.newSpace.confs.push(conf);
      this.spaceService.addConf(this.newSpace).subscribe((all) => {
        this.newSpace = all;
        alert("Conf added");
      })
      //alert(JSON.stringify(this.newSpace));
    }


  }

  availableTime(res: ReservationType) {
    let avb = false;
    const fromDate = new Date(res.from);
    const TEN_MIN = 10 * 60 * 1000;
    if ((Date.now() - fromDate.getTime()) <= TEN_MIN && (Date.now() - fromDate.getTime()) > 0) {
      avb = true;
    }
    return avb;
  }

  //Napomena zarad testiranja stoji !avb u pravoj verziji stoji samo avb
  //Ovo vazi i za confirm i reject

  confirm(res: ReservationType) {
    //alert(this.availableTime(res));
    let avb = this.availableTime(res);
    if (avb) {
      this.reservationService.showedUpdate(res, true).subscribe((cnf) => {
        alert("Updated showed!");
      })
    }
    else {
      alert("Nije pocela rezervacija!");
    }
  }

  reject(res: ReservationType) {
    let avb = this.availableTime(res);
    if (avb) {
      this.spaceService.addStrike(res.user, res.space).subscribe((cnf) => {
        alert("Added strike!");
      })
      this.reservationService.showedUpdate(res, false).subscribe((cnf) => {
        alert("Updated showed!");
      })
    }
    else {
      alert("Nije pocela rezervacija!");
    }
  }


  showReservation(space: SpaceType, tip: string) {

  }
}
