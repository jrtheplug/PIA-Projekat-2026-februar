import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SpaceType } from '../models/space';
import { UserType } from '../models/user';
import { Router, RouterLink } from '@angular/router';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { CommonModule, DatePipe, SlicePipe } from '@angular/common';
import { UserService } from '../services/user.service';
import { SpaceService } from '../services/space.service';
import { ReservationService } from '../services/reservation.service';
import { ReservationType } from '../models/reservation';
import { Calendar, CalendarOptions } from '@fullcalendar/core';
import { FullCalendarComponent, FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import { Office } from '../models/office';
import { Comments } from '../models/comments';
import interactionPlugin, { DateClickArg } from '@fullcalendar/interaction';
import { Conf } from '../models/conf';

@Component({
  selector: 'app-detalj',
  standalone: true,
  imports: [FormsModule, CommonModule, FullCalendarModule, DatePipe, RouterLink],
  templateUrl: './detalj.component.html',
  styleUrl: './detalj.component.css'
})
export class DetaljComponent {

  space: SpaceType = new SpaceType();
  loggedUser: UserType = new UserType();

  private router = inject(Router);
  private userService = inject(UserService);
  private spaceService = inject(SpaceService);
  private reservationService = inject(ReservationService);

  safeUrl!: SafeResourceUrl;
  safeUrlIMG!: SafeUrl;
  safeIMGS!: SafeUrl[];
  date: Date = new Date();
  offices: Office[] = [];
  confs: Conf[] = [];
  reservationList: ReservationType[] = [];
  selectedElementReservations: ReservationType[] = [];
  commentsList: SpaceType[] = [];
  komentar = "";

  names: string[] = [];

  //@ViewChild('calendar') calendarComponent: FullCalendarComponent;

  calendarOptions: CalendarOptions = {
    initialView: 'timeGridWeek',
    plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
    timeZone: 'UTC',
    dateClick: (arg) => this.handleDateClick(arg),
    events: []
  };

  start: Date = new Date();
  end: Date = new Date();
  type = "";
  naziv = "";

  handleDateClick(arg: DateClickArg) {
    this.type = "";
    //alert('date click! ' + arg.dateStr)
    this.start = new Date(arg.date);
    this.end = new Date(arg.date);
    this.end.setHours(arg.date.getHours() + 1);
    //console.log(this.start + "###" + this.end);
    this.calendarOptions.events = [{ title: "Potencijalna rezervacija", start: this.start, end: this.end }];

    this.naziv = this.names[this.currentIndex];
    //alert(naziv);

    this.offices.forEach(o => {
      if (o.name == this.naziv) {
        this.type = "office";
      }
    })

    this.confs.forEach(c => {
      if (c.name == this.naziv) {
        this.type = "confs";
      }
    })

    if (this.type == "") {
      this.type = "openSpace";
    }

    //alert(this.type);
  }

  addReservation() {
    let nova = new ReservationType();
    nova.user = this.loggedUser;
    nova.space = this.space;
    nova.name = this.naziv;
    nova.from = this.start;
    nova.to = this.end;
    nova.type = this.type;
    nova.status = "A";

    this.reservationService.addReservation(nova).subscribe((cnf) => {
      alert("Rezervacija dodata!");
    })
  }


  currentIndex = 0;
  next() {
    if (this.currentIndex < this.names.length - 1) {
      this.currentIndex++;
    }
  }

  prev() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
    }
  }

  events: any[] = [];
  dates: number[] = [];
  element = ""
  onSelectChangeElement() {
    this.selectedElementReservations = [];
    this.events = [];
    //alert(this.element);
    if (this.element.match("otvoreni prostor")) {
      this.element = ""
      //alert("DA");
    }
    this.reservationService.reservationsByElement(this.space, this.names[this.currentIndex]).subscribe((all) => {
      //alert(JSON.stringify(all[0]));
      this.selectedElementReservations = all;
      //alert(JSON.stringify(all));
      //console.log(JSON.stringify(all));

      this.selectedElementReservations.forEach(e => {
        //alert(JSON.stringify(e));
        //alert(JSON.stringify(e.from));
        //alert(this.reservationList[0].from.getFullYear())
        let date = new Date(e.from);
        this.dates.push(date.getDate());
        this.events.push({ id: e._id, title: e.name, start: e.from, end: e.to })


        //alert(date.getDate());
      })
      this.calendarOptions.events = this.events;
    })
    localStorage.setItem("month", JSON.stringify(new Date().getMonth() + 1))
  }

  selectedImage!: SafeUrl;

  constructor(private sanitizer: DomSanitizer) { }

  setUrl(url: string) {
    this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
  setUrlIMG(url: string) {
    this.safeUrlIMG = this.sanitizer.bypassSecurityTrustUrl(url);
  }

  ngOnInit(): void {
    this.space = JSON.parse(localStorage.getItem("space")!);
    this.loggedUser = JSON.parse(localStorage.getItem("loggedUser")!);

    this.setUrl(this.space.location);
    this.safeIMGS = [];
    this.space.pictures.forEach(element => {
      //alert(JSON.stringify(element))
      this.setUrlIMG(element);
      this.safeIMGS.push(this.safeUrlIMG);
    });

    this.userService.userByID(this.space.manager).subscribe((men) => {
      this.space.manager = men;
      console.log(JSON.stringify(this.space.manager));
    })


    this.space.offices.forEach(element => {
      //alert(JSON.stringify(element))
      //alert(JSON.stringify(element));
    });
    this.offices = this.space.offices;
    this.confs = this.space.confs;

    this.names.push("openSpace");
    this.offices.forEach(o => {
      this.names.push(o.name);
    })
    this.confs.forEach(c => {
      this.names.push(c.name);
    })
    //alert(this.space.name);
    this.reservations(this.space);
    //alert( this.dates.includes(this.date.getDate()));
    this.selectedImage = this.safeIMGS[0];
  }

  setMainImage(i: number) {
    this.selectedImage = this.safeIMGS[i];
  }

  profil(manager: UserType) {
    localStorage.setItem("manager", JSON.stringify(manager));
    this.router.navigate(["/profil"]);
  }

  reservations(name: SpaceType) {
    this.reservationService.reservationsSpace(name).subscribe((all) => {
      this.reservationList = all;
      //alert(JSON.stringify(all));

      this.reservationList.forEach(e => {
        //alert(JSON.stringify(e));
        //alert(JSON.stringify(e.from));
        //alert(this.reservationList[0].from.getFullYear())
        //alert(JSON.stringify(this.reservationList));
        //alert(JSON.stringify(e.user));
        if (e.user.toString() == this.loggedUser._id)
          this.ukp += 1;
        let date = new Date(e.from);
        this.dates.push(date.getDate());
        this.events.push({ title: e.name, start: e.from, end: e.to })


        //alert(date.getDate());
      })
      this.calendarOptions.events = this.events;
    })
  }

  posible() {
    let pos = false;

    this.reservationList.forEach(r => {
      //alert(r.user._id!);
      //alert(this.space.manager._id! );
      if (r.user == this.space.manager)
        pos = true;
    })
    //alert(pos);
    return true;
  }

  numRes() {
    let num = 0;
    this.reservationList.forEach(res => {
      if (res.user._id == this.loggedUser._id)
        num += 1;
    })
    return num;
  }

  broj = 0;
  brojK = 0;
  ukp = 0;
  like(s: SpaceType) {
    //alert(this.ukp);
    if (this.broj < this.ukp) {
      this.broj += 1;
      this.spaceService.like(this.space).subscribe((all) => {
        alert("liked");
        this.space = all;
      })
      localStorage.setItem("space", JSON.stringify(this.space));
    }
    else {
      alert("Ne mozete vise lajkovati :(");
    }

  }
  dislike(s: SpaceType) {
    if (this.broj < this.ukp) {
      this.broj += 1;
      this.spaceService.dislike(this.space).subscribe((all) => {
        alert("disliked");
      })
    }
    else {
      alert("Ne mozete vise disjalkovati :(");
    }
  }


  comment() {
    if (this.brojK < this.ukp) {
      this.brojK += 1;
      let com = new Comments();
      com.username = this.loggedUser.username;
      com.datum = new Date();
      com.text = this.komentar;

      this.space.comments.push(com);

      this.spaceService.addComment(this.space).subscribe((s) => {
        this.space = s;
      })
    }
    else {
      alert("Ne mozete vise komentarisati :(");
    }
  }
}
