import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetaljComponent } from './detalj.component';

describe('DetaljComponent', () => {
  let component: DetaljComponent;
  let fixture: ComponentFixture<DetaljComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetaljComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DetaljComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
