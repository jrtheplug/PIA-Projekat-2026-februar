import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserType } from '../models/user';
import { SpaceType } from '../models/space';
import { UserService } from '../services/user.service';
import { SpaceService } from '../services/space.service';
import { Router, RouterLink } from '@angular/router';
import { ChartComponent } from '../chart/chart.component';

@Component({
  selector: 'app-admin-panel',
  standalone: true,
  imports: [FormsModule, ChartComponent, RouterLink],
  templateUrl: './admin-panel.component.html',
  styleUrl: './admin-panel.component.css'
})
export class AdminPanelComponent {
  private userService = inject(UserService);
  private spaceService = inject(SpaceService);
  private router = inject(Router);
  userList: UserType[] = [];
  spaceList: SpaceType[] = [];

  userMap: { [key: string]: UserType } = {};
  ngOnInit(): void {
    this.userService.allUsersNA().subscribe((all) => {
      this.userList = all;
    })

    this.spaceService.allSpacesNA().subscribe((all) => {
      this.spaceList = all;
    })

    this.userService.allUsers().subscribe((users) => {
      users.forEach(u => {
        this.userMap[u._id] = u;
      })
      console.log(JSON.stringify(this.userMap));
    })
  }

  denyU(u: UserType) {
    this.userService.denyU(u).subscribe((cnf) => {
      alert("User denied!");
    })
  }

  denyS(s: SpaceType) {
    this.spaceService.denyS(s).subscribe((cnf) => {
      alert("Space denied!");
    })
  }

  acceptU(u: UserType) {
    this.userService.acceptU(u).subscribe((cnf) => {
      alert("User accepted!");
    })
  }

  acceptS(s: SpaceType) {
    this.spaceService.acceptS(s).subscribe((cnf) => {
      alert("Space accepted!");
    })
  }

  deleteU(u: UserType){
    this.userService.deleteU(u).subscribe((cnf) => {
      alert("User deleted!");
    })
  }

  detailU(u: UserType){
    localStorage.setItem("detaljniKorisnik", JSON.stringify(u));
    this.router.navigate(["detaljiOKorisniku"]);
  }

}
