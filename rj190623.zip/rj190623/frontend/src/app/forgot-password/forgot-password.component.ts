import { Component, inject } from '@angular/core';
import { UserService } from '../services/user.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css'
})
export class ForgotPasswordComponent {
  username = "";
  private userService = inject(UserService);
  private router = inject(Router);
  token = "";

  sendLink(){
    //alert(this.username);
    this.userService.sendLink(this.username).subscribe((cnf) => {
      this.token = cnf;
      //alert(this.token);
      localStorage.setItem("token", this.token);
      this.router.navigate(["reset"]);
    })
  }
}
