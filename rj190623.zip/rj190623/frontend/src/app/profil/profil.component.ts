import { Component, inject } from '@angular/core';
import { UserType } from '../models/user';
import { SpaceType } from '../models/space';
import { Router, RouterLink } from '@angular/router';
import { SpaceService } from '../services/space.service';
import { FormsModule } from '@angular/forms';
import { ReservationService } from '../services/reservation.service';
import { ReservationType } from '../models/reservation';
import { DatePipe } from '@angular/common';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-profil',
  standalone: true,
  imports: [FormsModule, DatePipe, RouterLink],
  templateUrl: './profil.component.html',
  styleUrl: './profil.component.css'
})
export class ProfilComponent {

  searchList: SpaceType[] = [];
  cityList: SpaceType[] = [];
  user: UserType = new UserType();
  reservationList: ReservationType[] = [];
  private userService = inject(UserService);
  private spaceService = inject(SpaceService);
  private reservationService = inject(ReservationService);
  private router = inject(Router);
  name = ""
  city = ""
  sto = ""
  kanc = ""
  velicina = 0
  konf = ""


  firstname = ""
  lastname = ""
  email = ""
  phone = ""
  password = ""
  file!: File;
  imageBase64!: string;


  userMap: { [key: string]: UserType } = {};
  spaceMap: { [key: string]: SpaceType } = {};

  getUsers() {

    this.userService.allUsers().subscribe((users) => {
      users.forEach(u => {
        this.userMap[u._id] = u;
      })
    })

  }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("loggedUser")!);

    this.spaceService.allCities().subscribe((all) => {
      this.searchList = all;
    })

    this.spaceService.allCities().subscribe((all) => {
      this.cityList = all;
    })

    this.reservationService.reservationsUser(this.user).subscribe((all) => {
      this.reservationList = all;
    })

    this.userService.allUsers().subscribe((users) => {
      users.forEach(u => {
        this.userMap[u._id] = u;
      })
      console.log(JSON.stringify(this.userMap));
    })

    this.spaceService.allCities().subscribe((spaces) => {
      spaces.forEach(s => {
        this.spaceMap[s._id] = s;
      })
      console.log(JSON.stringify(this.spaceMap));
    })

  }

  onFileSelected(event: any) {
    const img: File = event.target.files[0];

    if (img) {
      this.file = img;

      const reader = new FileReader();
      reader.readAsDataURL(img);

      reader.onload = () => {
        this.imageBase64 = reader.result as string;
        console.log(this.imageBase64);
      };
    }
  }

  passwordRegex: RegExp =
    /^[A-Za-z](?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,12}$/;

  emailRegex: RegExp = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  isValidPassword(password: string): boolean {
    return this.passwordRegex.test(password);
  }

  isValidEmail(email: string): boolean {
    return this.emailRegex.test(email);
  }

  updateUser() {
    let newUser = this.user;
    //alert(this.user.firstname +"#" + this.firstname)
    if (this.user.firstname != this.firstname && !(this.firstname === "")) {
      newUser.firstname = this.firstname;
    }
    //alert(this.user.lastname +"#" + this.lastname)
    //alert(this.user.lastname.match(this.lastname));
    //alert(this.lastname === "")
    if (this.user.lastname != this.lastname && !(this.lastname === "")) {
      newUser.lastname = this.lastname;
    }
    if (!this.user.email.match(this.email)) {
      if (this.isValidEmail(this.email)) {
        newUser.email = this.email;
      } else {
        alert("Neispravan email");
      }

    }
    if (!this.user.phone.slice(1,).match(this.phone.slice(1,))) {
      newUser.phone = this.phone;
    }
    if (this.password.length != 0) {
      //alert(this.password);
      if (this.isValidPassword(this.password)) {
        newUser.password = this.password;
      }
      else {
        alert("Neispravan password");
      }

    }

    if (this.imageBase64 != null) {
      //alert("Da");
      newUser.picture = this.imageBase64;
    }

    //alert(this.user.lastname);
    this.userService.updateUser(newUser).subscribe((cnf) => {
      this.user = cnf;
      alert("User updated!");
    })
  }

  sortNameDSC() {
    //alert(JSON.stringify(this.searchList));
    this.searchList.sort((a, b) => b.name.localeCompare(a.name));
    //alert(JSON.stringify(this.searchList));
  }

  sortNameASC() {
    //alert(JSON.stringify(this.searchList));
    this.searchList.sort((a, b) => a.name.localeCompare(b.name));
    //alert(JSON.stringify(this.searchList));
  }

  sortCityASC() {
    //alert(JSON.stringify(this.searchList));
    this.searchList.sort((a, b) => a.city.localeCompare(b.city));
    //alert(JSON.stringify(this.searchList));
  }

  sortCityDSC() {
    //alert(JSON.stringify(this.searchList));
    this.searchList.sort((a, b) => b.city.localeCompare(a.city));
    //alert(JSON.stringify(this.searchList));
  }


  search() {
    //alert(this.sto);
    //alert(this.kanc);
    //alert(this.konf);

    if (this.konf) {
      this.searchList = [];
      this.spaceService.search(this.name, this.city).subscribe((res) => {
        res.forEach((space) => {
          if (space.confs.length > 0) {
            this.searchList.push(space);
          }
        })
      })
    } else if (this.kanc) {
      let moze = false;
      this.searchList = [];
      this.spaceService.search(this.name, this.city).subscribe((res) => {
        res.forEach((space) => {
          moze = false;
          space.offices.forEach((office) => {
            if (office.size >= this.velicina) {
              moze = true;
              return;
            }
          })
          if (moze) {
            this.searchList.push(space);
          }
        })
      })
    } else {
      this.spaceService.search(this.name, this.city).subscribe((res) => {
        this.searchList = res;
        //alert(this.searchList.length)
        //alert(JSON.stringify(this.searchList));
      })
    }

  }

  detalj(space: SpaceType) {
    localStorage.setItem("space", JSON.stringify(space));
    this.router.navigate(["/details"]);
  }

  cancelRes(res: ReservationType) {
    let rezVreme = new Date(res.from);
    //alert(rezVreme.getTime());
    //alert(Date.now());
    if (rezVreme.getTime() - Date.now() > (12 * 60 * 60 * 1000)) {
      //alert("DA");
      this.reservationService.cancelReservation(res).subscribe((all) => {
        alert("reservation cancel");
      })
    }
    else{
      alert("Ne mozete otkazati rezervaciju manje od 12 sati pre termina!");
    }

  }

}
