import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { SpaceType } from '../models/space';
import { ReservationType } from '../models/reservation';
import { UserType } from '../models/user';
import { BansType } from '../models/bans';

@Injectable({
  providedIn: 'root'
})
export class SpaceService {
  private http = inject(HttpClient)
  constructor() { }

  allCities() {
    return this.http.get<SpaceType[]>("http://localhost:4000/spaces/allcities");
  }

  search(n: string, c: string) {
    const data = {
      name: n,
      city: c
    }
    return this.http.post<SpaceType[]>("http://localhost:4000/spaces/search", data);
  }

  top() {
    return this.http.get<SpaceType[]>("http://localhost:4000/spaces/top");
  }

  like(s: SpaceType) {
    return this.http.post<SpaceType>("http://localhost:4000/spaces/like", s);
  }

  dislike(s: SpaceType) {
    return this.http.post<SpaceType>("http://localhost:4000/spaces/dislike", s);
  }


  allComments(s: SpaceType) {
    return this.http.post<SpaceType[]>("http://localhost:4000/spaces/allComments", s);
  }

  spacesByManagerCompany(user: UserType){
    const data = {
      user: user
    }
    return this.http.post<SpaceType[]>("http://localhost:4000/spaces/spacesByManagerCompany", data);
  }

  addSpace(s: SpaceType){
    return this.http.post<SpaceType>("http://localhost:4000/spaces/addSpace", s);
  }

  addOffice(s: SpaceType){
    return this.http.post<SpaceType>("http://localhost:4000/spaces/addOffice", s);
  }

  addConf(s: SpaceType){
    return this.http.post<SpaceType>("http://localhost:4000/spaces/addConf", s);
  }

  addStrike(u: UserType, s: SpaceType){
    const data = {
      user: u,
      space: s
    }
    return this.http.post<BansType>("http://localhost:4000/spaces/addStrike", data);
  }

  allSpacesNA(){
    return this.http.get<SpaceType[]>("http://localhost:4000/spaces/allSpacesNA");
  }

  denyS(s: SpaceType){
    return this.http.post<SpaceType>("http://localhost:4000/spaces/denyS", s);
  }

  acceptS(s: SpaceType){
    return this.http.post<SpaceType>("http://localhost:4000/spaces/acceptS", s);
  }

  addComment(s: SpaceType){
    return this.http.post<SpaceType>("http://localhost:4000/spaces/addComment", s);
  }
}
