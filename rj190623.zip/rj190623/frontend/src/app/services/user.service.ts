import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { UserType } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private http = inject(HttpClient)
  constructor() { }

  login(u: string, p: string){
    const data = {
      username: u,
      password: p
    }
    return this.http.post<UserType>("http://localhost:4000/users/login", data)
  }

  allUsersNA(){
    return this.http.get<UserType[]>("http://localhost:4000/users/allUsersNA");
  }


  register(t: string, u: string, p: string, e: string, ph: string, fn: string, ln: string, image: string){
    const data = {
      type: t,
      username: u,
      password: p,
      email: e,
      phone: ph,
      firstname: fn,
      lastname: ln,
      picture: image
    }

    const formData = new FormData();
    formData.append("image", image);
    formData.append("username", u);
    formData.append("password", p);
    formData.append("email", e);
    formData.append("phone", ph);
    formData.append("firstname", fn);
    formData.append("lastname", ln);

    return this.http.post<UserType>("http://localhost:4000/users/register", data)
  }

   registerM(t: string, u: string, p: string, e: string, ph: string, fn: string, ln: string, image: string, c: string, a: string, m: number, pib: number){
    const data = {
      type: t,
      username: u,
      password: p,
      email: e,
      phone: ph,
      firstname: fn,
      lastname: ln,
      picture: image,
      company: c,
      address: a,
      maticni: m,
      pib: pib
    }

    const formData = new FormData();
    formData.append("image", image);
    formData.append("username", u);
    formData.append("password", p);
    formData.append("email", e);
    formData.append("phone", ph);
    formData.append("firstname", fn);
    formData.append("lastname", ln);

    return this.http.post<UserType>("http://localhost:4000/users/registerM", data)
  }

  denyU(u: UserType){
    return this.http.post<UserType>("http://localhost:4000/users/denyU", u);
  }

  acceptU(u: UserType){
    return this.http.post<UserType>("http://localhost:4000/users/acceptU", u);
  }

  updateUser(u: UserType){
    return this.http.post<UserType>("http://localhost:4000/users/updateUser", u);
  }

  deleteU(u: UserType){
    return this.http.post<UserType>("http://localhost:4000/users/deleteUser", u);
  }

  userByID(index: UserType){
    const data = {
      index: index
    }
    return this.http.post<UserType>("http://localhost:4000/users/userByID", data);
  }

  sendLink(username: string){
    const data = {
      username: username
    }
    return this.http.post<string>("http://localhost:4000/users/forgotPassword", data);
  }

  resetPassword(token: string, password: string){
    const data = {
      token: token,
      password: password
    }
    return this.http.post<string>("http://localhost:4000/users/resetPassword", data);
  }

  allUsers(){
    return this.http.get<UserType[]>("http://localhost:4000/users/allUsers");
  }

}
