import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { ReservationType } from '../models/reservation';
import { SpaceType } from '../models/space';
import { UserType } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class ReservationService {

  constructor() { }
  private http = inject(HttpClient)

  reservationsSpace(n: SpaceType){
    const data = {
      space: n
    }
    return this.http.post<ReservationType[]>("http://localhost:4000/reservations/bySpace", data);
  }

  reservationsUser(u: UserType){
    const data = {
      user: u
    }
    return this.http.post<ReservationType[]>("http://localhost:4000/reservations/byUser", data);
  }

   reservationsManager(m: UserType){
    const data = {
      manager: m
    }
    return this.http.post<ReservationType[]>("http://localhost:4000/reservations/byManager", data);
  }

  reservationsByElement(s: SpaceType, n: string){
    const data = {
      space: s,
      name: n
    }
    return this.http.post<ReservationType[]>("http://localhost:4000/reservations/byElement", data);
  }

  cancelReservation(r: ReservationType){
    const data = {
      reservation: r
    }
    return this.http.post<ReservationType[]>("http://localhost:4000/reservations/cancel", data);
  }

  showedUpdate(r: ReservationType, sh: boolean){
    const data = {
      reservation: r,
      showed: sh
    }
    return this.http.post<ReservationType[]>("http://localhost:4000/reservations/showed", data);
  }


  reservationsBetween(s: SpaceType, st: Date, end: Date, n: string){
    const data = {
      space: s,
      start: st,
      end: end,
      name: n
    }
    return this.http.post<ReservationType[]>("http://localhost:4000/reservations/between", data);
  }

  changeReservationTime(res: ReservationType){
    return this.http.post<ReservationType>("http://localhost:4000/reservations/changeReservationTime", res);
  }

  addReservation(res: ReservationType){
    return this.http.post<ReservationType>("http://localhost:4000/reservations/addReservation", res);
  }
}
