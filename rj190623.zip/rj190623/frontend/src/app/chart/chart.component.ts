import { Component, inject, ViewChild } from '@angular/core';
import { ChartConfiguration, ChartData, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { SpaceService } from '../services/space.service';
import { SpaceType } from '../models/space';
import { ReservationService } from '../services/reservation.service';
import { finalize, forkJoin, map, switchMap } from 'rxjs';

@Component({
  selector: 'app-chart',
  standalone: true,
  imports: [BaseChartDirective],
  templateUrl: './chart.component.html',
  styleUrl: './chart.component.css'
})
export class ChartComponent {
  @ViewChild(BaseChartDirective) chart?: BaseChartDirective;

  private spaceService = inject(SpaceService);
  private reservationService = inject(ReservationService);
  spaceList: SpaceType[] = [];
  likes: number[] = [];
  money: number[] = [];
  labels: string[] = [];

  ngOnInit(): void {
    this.spaceService.allCities().pipe(switchMap((all) => {
      this.spaceList = all;

      this.labels = this.spaceList.map(space => space.name.toString());
      this.likes = this.spaceList.map(space => space.likes);

      const res = this.spaceList.map(space => this.reservationService.reservationsSpace(space).pipe(map(allRes => (space.price * allRes.length))));
      return forkJoin(res);

    })).subscribe((allFork) => {

      this,this.money = allFork;
      //alert(this.likes);
      this.barChartData.labels = this.labels;
      this.barChartData.datasets[0].data = this.likes;
      this.barChartData.datasets[1].data = this.money;

      this.chart?.update();
    });
  }

  public barChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    // maintainAspectRatio: false // Optional: adjust as needed
  };
  public barChartType: ChartType = 'bar';
  public barChartData: ChartData<'bar'> = {
    labels: [],
    datasets: [
      { data: [], label: 'Popularnost' },
      { data: [], label: 'Cena' }
    ]
  }
}
