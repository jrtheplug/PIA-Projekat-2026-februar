import { Component, inject } from '@angular/core';
import { UserType } from '../models/user';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './admin-login.component.html',
  styleUrl: './admin-login.component.css'
})
export class AdminLoginComponent {
  username = ""
  password = ""
  user: UserType = new UserType();

  private router = inject(Router);
  private userService = inject(UserService);

  login() {
    this.userService.
      login(this.username, this.password).subscribe((all) => {
        if (all.type == "admin") {
          alert("Login succesfull");
          this.user = all;
          localStorage.setItem("loggedUser", JSON.stringify(this.user));
          if (this.user.type == "admin") {
            this.router.navigate(["/admin"]);
          }
        }
        else {
          alert("No admin account")
        }
      })
  }
}
