import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SpaceService } from '../services/space.service';
import { Router, RouterLink } from '@angular/router';
import { SpaceType } from '../models/space';
import { UserType } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-pocetna',
  standalone: true,
  imports: [FormsModule, RouterLink],
  templateUrl: './pocetna.component.html',
  styleUrl: './pocetna.component.css'
})
export class PocetnaComponent {
  
  name = ""
  cityList: SpaceType[] = []
  city = ""
  searchList: SpaceType[] = []
  topList: SpaceType[] = []
  private spaceService = inject(SpaceService);
  private userService = inject(UserService);
  private router = inject(Router);

  userMap: { [key: string]: UserType } = {};

  ngOnInit(): void{
    localStorage.setItem("loggedUser", JSON.stringify(null));

    this.spaceService.allCities().subscribe((all) => {
      this.cityList = all;
    })

    this.spaceService.top().subscribe((all) => {
      this.topList = all;
    })

    this.userService.allUsers().subscribe((users) => {
      users.forEach(u => {
        this.userMap[u._id] = u;
      })
      console.log(JSON.stringify(this.userMap));
    })
  }

  search(){
    this.spaceService.search(this.name, this.city).subscribe((res) => {
        this.searchList = res;
        //alert(this.searchList.length)
        //alert(JSON.stringify(this.searchList));
    })
  }

  sortNameDSC(){
    //alert(JSON.stringify(this.searchList));
    this.searchList.sort((a, b) => b.name.localeCompare(a.name));
    //alert(JSON.stringify(this.searchList));
  }

  sortNameASC(){
    //alert(JSON.stringify(this.searchList));
    this.searchList.sort((a, b) => a.name.localeCompare(b.name));
    //alert(JSON.stringify(this.searchList));
  }

  sortCityASC(){
    //alert(JSON.stringify(this.searchList));
    this.searchList.sort((a, b) => a.city.localeCompare(b.city));
    //alert(JSON.stringify(this.searchList));
  }

  sortCityDSC(){
    //alert(JSON.stringify(this.searchList));
    this.searchList.sort((a, b) => b.city.localeCompare(a.city));
    //alert(JSON.stringify(this.searchList));
  }

  detalj(space: SpaceType){
    localStorage.setItem("space", JSON.stringify(space));
    this.router.navigate(["/details"]);
  }
}
